package game.server;

public class RunServer {

	public static void main(String[] args) {
		System.out.println("서버접속을 시도합니다");
		new GameServer();
	}

}
