package play.multi;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;

import login.view.FirstMain;
import login.view.LoginNickName;
import login.view.NicknameDialog;

public class MultiGameDisplay extends JFrame implements ActionListener  {
	private JButton[] card = new JButton[24];
	private JButton start, exit;
	private JLabel myScoreLabel, otherScoreLabel;
	private int score=0;
	private JPanel gamePane, rightPane, btnPane, scorePane;
	private ImageIcon imageIcon[]=new ImageIcon[20] ;			// 앞면 이미지 저장할 20개 아이콘들

	public MultiGameDisplay(String userNick) {
	
		System.out.println("게임화면 닉네임 : "+userNick);
		System.out.println("멀티게임실행");

		this.setTitle("카드 짝맞추기 - 멀티게임");
		this.setBounds(new Rectangle(150,150,1200,800));
		this.setLayout(new BorderLayout());
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE); // 창 닫을때 프로그램 종료시킴

		GridLayout grid = new GridLayout(2, 1); 

		gamePane = new JPanel(new GridLayout(4,6));
		rightPane = new JPanel(new BorderLayout());
		btnPane = new JPanel(grid);
		scorePane = new JPanel();
		
		for(int i=0; i<card.length; i++){
			card[i] = new JButton(new ImageIcon("images/화투 그림/"+(i+1)+ ".jpg"));
			gamePane.add(card[i]);
		}
		start = new JButton("게임시작");
		exit = new JButton("나가기");
		
		start.setPreferredSize(new Dimension(70, 50));
		grid.setVgap(23);

		
		myScoreLabel = new JLabel(userNick+"님의 점수 : ");
		otherScoreLabel = new JLabel(userNick+"님의 점수 : ");
		
		rightPane.add(scorePane, BorderLayout.NORTH);
		rightPane.add(btnPane, BorderLayout.SOUTH);
		scorePane.add(myScoreLabel);
		scorePane.setPreferredSize(new Dimension(200, 200));	
		scorePane.setBackground(Color.WHITE);
		
//		btnPane.setPreferredSize(new Dimension(150, 100));	

		exit.addActionListener(this);


		btnPane.add(start);
		btnPane.add(exit);
		
		this.add(gamePane, BorderLayout.WEST);
		this.add(rightPane, BorderLayout.EAST);
		
		this.setVisible(true);

	}

	

	@Override
	public void actionPerformed(ActionEvent event) {
		switch (event.getActionCommand()) {
		case "게임시작":
			
			break;
		case "나가기":
			int result = JOptionPane.showConfirmDialog(getParent(), "메인화면으로 돌아가시겠습니까?", "게임 나가기",
					JOptionPane.YES_NO_OPTION);
			if (result == 0){
				new FirstMain();
				this.setVisible(false);
			}
				break;
		}

	}
}