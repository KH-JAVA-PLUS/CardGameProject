package play.multi;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;

import java.awt.event.*;
import java.io.File;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.event.*;

import model.LoginNickName;
import view.FirstMain;
import view.NicknameDialog;

public class MultiGameDisplay extends JFrame implements ActionListener, Runnable{
	//right 메뉴 부분
	private JButton start, exit;
	private JLabel myScoreLabel ,otherScoreLabel;
	private int myScore=0;
	private int otherScore=0;
	private JPanel rightPane, btnPane, scorePane;
	private JLabel firstScore, secendScore;
	
	//네트워크 부분
	private String ip = "127.0.0.1", nik;
	private Socket server;
	private final int port = 5252;
	private PrintWriter pw;                 
	private BufferedReader br; 
	
	// 게임구현부분
	File path = new File("");
	private ImageIcon imageBack ;
	int cardrandom[] = new int [24]; // 카드 랜덤번호가 들어갈 배열
	private JLabel[] labelImage = new JLabel[24];  //이미지 올려놓을 위치(버튼)
	private JPanel gamePane;
	private ImageIcon imageIcon[]=new ImageIcon[24] ;			// 앞면 이미지 저장할 24개 아이콘들
	private int startCheck;		// 새게임버튼 안누르고 그림 누를경우엔 0, 새게임 누르고 패누를땐 1
	private Timer timerMix = new Timer();		// 패를 섞을때 속도 조절위한 타이머 초기화
	private Timer timerHide = new Timer();		// 패를 뒤집기전에 패를 몇초간 보여줄지 타이머
	private Timer timerCardCheck = new Timer();		// 패 2개를 뒤집고나서 틀렸을 경우 몇초간 보여줄지 타이머
	private JLabel labelConfirmedCheck;   	// 2개 패 찾기를 성공한것을 누른건지 확인하기위한버튼
	private JLabel labelSelectedFirst;		// 처음 선택된 버튼
	private JLabel labelSelectedSecond;		// 두번째 선택된 버튼
	private int selectedTwoCardCheck;		// 버튼이 몇번 눌렷는지 체크하기
	private int firstCardNumber;		// 첫번째 눌린 버튼에서 배열의 카드번호 저장하기위해
	private int secondCardNumber;	// 두번째 눌린 버튼에서 배열의 카드번호 저장하기위해
	private int selectedImageNumber ;		// 몇번째 버튼인지 확인하기 위한 눌려진 버튼의 번호 저장
	private ImageIcon selectedImage ;		// 눌려진 이미지 보여주기위해
	private Timer timerSec = new Timer();// 라벨의 타이머 초기화
	private int sec=0;
	
	// 결과 팝업창
	private JDialog dialogResult;
	private JLabel labelResultText;
	private JLabel labelResultScore;
	private JButton buttonResultOK;
	private int cardPuzzleScore=0;
	
	public MultiGameDisplay() {}
	public MultiGameDisplay(String userNick) {
		nik = userNick;

		System.out.println("멀티게임실행");

		this.setTitle("카드 짝맞추기 - 멀티게임");
		this.setBounds(new Rectangle(50,50,1100,800));
		this.setLayout(null);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE); // 창 닫을때 프로그램 종료시킴

		 
		//게임 부분
		gamePane = new JgamePane();
		
		labelResultText = new JLabel();
		labelResultScore = new JLabel();
		
		//스코어,버튼 부분
		rightPane = new JPanel(new BorderLayout());
		scorePane = new JPanel();
		
		myScoreLabel = new JLabel(userNick + "님 환영합니다.");
		otherScoreLabel = new JLabel();
		myScoreLabel.setFont(new Font(" ",0,15)); //font,0-PLAIN,size
		otherScoreLabel.setFont(new Font(" ",0,15)); //1-BOLD
		
		
		start = new JButton("게임시작");
		exit = new JButton("나가기");
		
		start.setBackground(Color.WHITE);
		exit.setBackground(Color.WHITE);
		
		
		rightPane.setBounds(830, 20, 225,720);
		
		scorePane.setBackground(Color.WHITE);
		scorePane.setPreferredSize(new Dimension(200, 200));	
		scorePane.setBorder(BorderFactory.createLoweredBevelBorder()); //스코어부분 테두리 bevelBorder
		
	
		GridLayout grid = new GridLayout(2, 1);
		btnPane = new JPanel(grid);
		
		btnPane.setPreferredSize(new Dimension(200, 100));
		start.setPreferredSize(new Dimension(60, 50));
		grid.setVgap(23);
		
		start.addActionListener(new MyActionListenerNewGame());
		
		exit.addActionListener(this);
	
		//다이얼로그
		buttonResultOK = new JButton("확    인");
		buttonResultOK.setFont(new Font("GOTHIC",Font.BOLD , 25));
		buttonResultOK.addActionListener(this);
		buttonResultOK.setPreferredSize(new Dimension(50,20));
		
		dialogResult = new JDialog(this, "게임 결과");
		dialogResult.setLayout(new GridLayout(3,1));
		dialogResult.setBounds(230, 300, 200, 150);
		dialogResult.add(labelResultText);
		dialogResult.add(labelResultScore);
		dialogResult.add(buttonResultOK);
		
		
		rightPane.add(scorePane, BorderLayout.NORTH);
		rightPane.add(btnPane, BorderLayout.SOUTH);
		scorePane.add(myScoreLabel);
		scorePane.add(otherScoreLabel);
		btnPane.add(start);
		btnPane.add(exit);
		
		this.add(gamePane, BorderLayout.WEST);
		this.add(rightPane, BorderLayout.EAST);
		
		
		
		this.setVisible(true);

	}

	

	@Override
	public void actionPerformed(ActionEvent event) {
		switch (event.getActionCommand()) {
		case "확    인":
			dialogResult.setVisible(false);
			break;
		case "나가기":
			int result = JOptionPane.showConfirmDialog(getParent(), "메인화면으로 돌아가시겠습니까?", "게임 나가기",
					JOptionPane.YES_NO_OPTION);
			if (result == 0){
				new FirstMain();
				this.setVisible(false);
			}
				break;
		}

	}
	
	class JgamePane extends JPanel{		// 게임 구현 패널
		
		public JgamePane(){
		
			setLayout(new GridLayout(4,6));
			setBounds(0,0,800,760);
			
			mixNumber();		// 패섞기
			setImage();			// 이미지 받아오기
			setButtonFirstImage();		// 버튼에 이미지 씌우기
			setButtonName();			// 버튼에 각각 이름 붙이기
			
			for(int i =0; i<24;i++){
				labelImage[i].addMouseListener(new jjacMouseListener());
			}
			
			for(int i =0; i<24;i++){
				add(labelImage[i]);
			}
		}
	}
	
	private class jjacMouseListener implements MouseListener{		// 두개 카드 확인 및 결과 표시
		public void mouseClicked(java.awt.event.MouseEvent e) {		
		}
		public void mouseEntered(java.awt.event.MouseEvent e) {
		}
		public void mouseExited(java.awt.event.MouseEvent e) {	
		}
		public void mousePressed(java.awt.event.MouseEvent e) {		
			labelConfirmedCheck = ((JLabel)e.getSource());
        	if(labelConfirmedCheck.getName()=="checked"){    // 눌린 버튼이 checked이면 성공한버튼 눌린거면 실행안하기
            	selectedTwoCardCheck =0;    // 성공한 패를 눌렀으므로 카운트 다시 0으로
            	
        	}else if(startCheck==1 && (selectedTwoCardCheck==0 || selectedTwoCardCheck==1)){  
        		// 카드가 뒤집어 졌을때만 실행하기위해

        			selectedTwoCardCheck += 1;		 // 카드 선택 될때마다 카운트 + 1
        	
        			// 첫번째 눌린 카드 번호
        			if(selectedTwoCardCheck==1){		
        				labelSelectedFirst=((JLabel)e.getSource());  // 첫번째 눌린 버튼객체 가져오기
        				selectedImageNumber =Integer.parseInt(labelSelectedFirst.getName())-1;  // 이름이 string 이므로 int로 변환
        				selectedImage = new ImageIcon(path+"images/화투 그림/"+cardrandom[selectedImageNumber]+".jpg"); 
        		
        				    // 버튼 눌려진 이미지 보여주기
        				labelSelectedFirst.setIcon(selectedImage); 
        				
        				firstCardNumber = cardrandom[selectedImageNumber];	// 카드 번호가 12이하면 그냥 저장 
        				if(cardrandom[selectedImageNumber]>12)			// 카드 번호가 12보다 크면 -12 (1-12 13-24 순서대로 같은그림 12차이)
        					firstCardNumber = cardrandom[selectedImageNumber]-12; 
        				
        			}// 첫번째 눌린 카드 번호

        			// 두번째 눌린 카드 번호
    				if(labelConfirmedCheck.getName()==labelSelectedFirst.getName()){		// 두번째 클릭이 처음클릭한 카드를 또 선택했으면 카운트0
    					selectedTwoCardCheck =1;
    				}else if(selectedTwoCardCheck==2	){			
        				labelSelectedSecond=((JLabel)e.getSource());  // 첫번째 눌린 버튼객체 가져오기
        				selectedImageNumber =Integer.parseInt(labelSelectedSecond.getName()) -1;  // 이름이 string 이므로 int로 변환
        				selectedImage = new ImageIcon(path +"images/화투 그림/"+cardrandom[selectedImageNumber]+".jpg");
        				
        				labelSelectedSecond.setIcon(selectedImage);     // 버튼 눌려진 이미지 보여주기
        				
        				secondCardNumber = cardrandom[selectedImageNumber];	// 카드 번호가 12이하면 그냥 저장
        				if(cardrandom[selectedImageNumber]>12)				// 카드 번호가 12보다 크면 -12
        					secondCardNumber = cardrandom[selectedImageNumber]-12; 
        				
        				if(firstCardNumber==secondCardNumber ){   	// 첫번째 두번째 선택된 카드 비교
        					selectedTwoCardCheck =0;		// 카드 2선택되면 다시  초기화
        					labelSelectedFirst.setName("checked"); 				// 성공이므로 버튼 이름 checked으로 해서 선택못하게 하기
        					labelSelectedSecond.setName("checked"); 			// 성공이므로 버튼 이름 checked으로 해서 선택못하게 하기
							
        					myScore+=100;
							myScoreLabel.setText("현재 점수 : "+myScore+"점");// 점수 추가
							/*plusScoreLabel.setText("Good !!       +100점");
							plusScoreLabel.setForeground(Color.BLUE);*/
							
        					int end=0;  // 패 몇개 맞췄는지 확인하기 
        					for(int i=0; i<24; i++){		 // 패 몇개 맞췄는지 확인하기 
        						if((labelImage[i].getName()).equals("checked")){
        							end=end+1;
        							if (end==24){		// 24개 전부 맞았는지 체크
        								
//        								timerSec.cancel();		//  타이머 정지
//        								labelTimer.setText("  "+sec+" 초");	
        								/*if(sec>100){  // 100초 넘도록 못 풀면 100초라고 본다 점수는 고로 0점
        									sec=100;
        								}*/
//        								cardPuzzleScore = score;
//        								myScoreLabel.setText("점수 :  "+cardPuzzleScore+" 점");
        								
        								dialogResult();
        								break;
        							}
        						}
        					}
        					
        				}else{
        					myScore-=10;
        					myScoreLabel.setText("현재 점수 : "+myScore+"점");
        				/*	plusScoreLabel.setText("Bad !!      -10점");
        					plusScoreLabel.setForeground(Color.RED);*/
        					
        					
        					timerCardCheck = new Timer();
        					timerCardCheck.scheduleAtFixedRate(new TimerTask() { 	//첫번째 두번째 카드비교후 틀리면 몇초보여주기간 
        						public void run() {
        							selectedTwoCardCheck =0;		// 카드 2선택되면 다시  초기화 , 카드가 뒷면보일때까지 다른것 선택못하게하기
        							labelSelectedFirst.setIcon(imageBack); 				// 틀렸으므로 첫번째 카드 다시 뒤집기
        							labelSelectedSecond.setIcon(imageBack); 			// 틀렸으므로 두번째 카드 다시 뒤집기
        							timerCardCheck.cancel();				// 뒤집고 타이머 종료
        						}
        					}, 300,1);				// 0.4초후 카드 뒷면 보이게 하기.
        				} 
        			}// 두번째 눌린 카드 번호		
        	}
			
		}
		public void mouseReleased(java.awt.event.MouseEvent e) {
		}
	}
	// 두개 카드 확인 및 결과 표시
	
	public void mixNumber(){			// 카드 섞기
		
		int i=0;
		int rand=0;
		while(true){
			
			rand =  (int)(Math.random()*24+1);
			cardrandom[i] =rand;

	  aa : for(int j=0; j<24; j++){			
				if(j==i)
					break aa ;
				if(cardrandom[j]==rand){
					i=i-1 ;
					}
			}i=i+1;
			if(i==-1)i=0;
			if(i==24)break;
		}
	
	}
	
	public void setImage(){				// 이미지객체에 그림 가져오기
		
		imageBack = new ImageIcon(path +"images/화투 그림/0.jpg");
		for ( int i = 0; i<24; i++){
			 imageIcon[i]= new ImageIcon(path +"images/화투 그림/"+cardrandom[i]+".jpg");
		}
	}

	public void setButtonFirstImage(){		// 버튼 설정 및 처음 가져온 그림 보여주기
		
		for ( int i = 0; i<24; i++){
			 labelImage[i] =  new JLabel(imageIcon[i]);
	
		}	
}

	public void setButtonResetImage(){		// 버튼에 리셋된 이미지 재설정하기

		for ( int i = 0; i<24; i++){
			 labelImage[i].setIcon(imageIcon[i]);
		}
	}
	
	public void setButtonName(){		// 버튼에 이름주기
		
		for ( int i = 0; i<24; i++){
			 labelImage[i].setName(Integer.toString(i+1));
		}		
	}

	public void hideButtonImage(){		// 버튼 그림 뒷면 보이기
		
		for ( int i = 0; i<24; i++){
			 labelImage[i].setIcon(imageBack);
		}	
	}
	
	void dialogResult(){		// 다이얼로그 보여주기
		
		labelResultText.setText("  축하합니다 !!");
		labelResultScore.setText("  점수 :  "+myScore+" 점 획득");
		dialogResult.setVisible(true);

}
	
	class MyActionListenerNewGame implements ActionListener {    //  게임 시작버튼
        @Override
        public void actionPerformed(ActionEvent e) {
        	
        	setButtonName(); 
        	startCheck=1; 
        	myScore = 0;
        	myScoreLabel.setText("현재 점수 : "+myScore+"점"); //점수 초기화
        	otherScoreLabel.setText(" ");
        	
        	timerMix.cancel();	
    	  	timerMix = new Timer();		// 타이머 객체 초기화
    	  	timerHide.cancel();	
    		timerHide = new Timer();		// 타이머 객체 초기화
          	timerSec.cancel();				// 타이머 객체 없애기
    	  	timerSec = new Timer();    // 타이머 객체 초기화
    	  	
        	timerMix.scheduleAtFixedRate(new TimerTask() { 		// 패 섞는 모션
        		int i=0;
				public void run() {
					mixNumber();
					setImage();
					setButtonResetImage();
					i=i+1;
					if(i==24)timerMix.cancel();			// 24번 섞었으면 타이머 종료시키기
				}
			}, 0,50);			// 0초후 실행해서 0.005초간격으로 섞기
 			
        	
    		timerHide.scheduleAtFixedRate(new TimerTask() {		// 패 4초 보여준 후 뒤집는 모션
    			public void run() {
    				hideButtonImage();
    				timerHide.cancel();
    			}
    		}, 3000, 1); 		// 2초후 실행
        
        
        }
     }
	@Override
	public void run() {
		try {
			server = new Socket(ip, port);

			br = new BufferedReader(new InputStreamReader(server.getInputStream()));
			pw = new PrintWriter(new OutputStreamWriter(server.getOutputStream()));
			
			pw.write(nik + "\n");
			pw.flush();
			
			String nickName = br.readLine();

//			myScoreLabel.setText(nik+"님이 입장하셨습니다.");
			otherScoreLabel.setText(nickName /*+"님이 입장하셨습니다"*/);
			System.out.println(nickName +"님이 입장하셨습니다");
			/*myScoreLabel.setText(myScoreLabel.getText() + nickName );
			otherScoreLabel.setText(nickName+"님의 점수 : "+otherScore+"점");
			*/
			

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
}