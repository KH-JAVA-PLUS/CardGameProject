package controller;

import java.util.*;
import java.net.*;
import java.io.*;

public class Server {
	public static final int port = 5252; //포트번호 생성
	private ServerSocket server;
	private Vector<Socket> clients = new Vector<Socket>();
	
	public Server(){}
	
	public void displayMsg(String clientMessage){
		System.out.println(clientMessage);
	}
	
	public Vector<Socket> getClients(){
		return clients;
	}
	
	public static void main(String[] args){
		Server s = new Server();
		try {
			s.server = new ServerSocket(port); //서버용 소켓객체 생성
			
			while (true) { //클라이언트가 연결을 요청할 때까지 기다림
				Socket client = s.server.accept(); //연결을 요청한 클라이언트의 요청 수락함
				s.clients.addElement(client);
				
				new ClientHandler(s, client).start();
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
