package view;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;

import model.LoginNickName;
import play.multi.MultiGameDisplay;

import java.io.*;
import java.net.Socket;

public class NicknameDialog extends JDialog implements ActionListener {
	private JTextField Nickname;
	private JButton loginBtn, closeBtn;
	private JPanel centerPane, southPane;
	private Socket socket;

	public NicknameDialog() {
		// 반드시 창이 닫아 져야 다음이 실행됨
		this.setTitle("닉네임 입력");
		this.setModal(true);
		this.setBounds(new Rectangle(400,500,300,100));
		this.setLayout(new BorderLayout());

		centerPane = new JPanel();

		// centerPane 에 붙일 것들
		Nickname = new JTextField(20); // 가로넓이 지정
		centerPane.setLayout(new FlowLayout());
		centerPane.setLocation(0, 70);
		centerPane.add(new JLabel("닉네임 : "));
		centerPane.add(Nickname);

		southPane = new JPanel();

		// southPane 에 붙일 것들
		loginBtn = new JButton("게임 접속");
		closeBtn = new JButton("닫기");
		southPane.add(loginBtn);
		southPane.add(closeBtn);

		loginBtn.addActionListener(this);
		closeBtn.addActionListener(this);

		this.add(centerPane, BorderLayout.CENTER);
		this.add(southPane, BorderLayout.SOUTH);

	}

	@Override
	public void actionPerformed(ActionEvent event) {
		LoginNickName ln = new LoginNickName();

		// 버튼 클릭시 동작 처리
		switch (event.getActionCommand()) {
		case "닫기":
			this.setVisible(false);
			break;
		case "게임 접속":
			String userNick = Nickname.getText();
			ln.setNickName(userNick);

			Thread t1 = new Thread(new MultiGameDisplay(userNick));
			t1.start();
			
			this.setVisible(false);
			break;

		}

	}
}
