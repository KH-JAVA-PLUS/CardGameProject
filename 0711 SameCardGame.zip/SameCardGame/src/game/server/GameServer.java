package game.server;

public class GameServer {
	public GameServer() {
		System.out.println("서버가동");
	}
}
