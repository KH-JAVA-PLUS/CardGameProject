package controller;

import java.util.*;
import java.net.*;
import java.io.*;

public class Server {
	public static final int port = 5252; //포트번호 생성
	public ServerSocket server;
	public Vector<Socket> clients = new Vector<Socket>();
	
	public Server(){}
	
	public void displayMsg(String clientMessage){
		System.out.println(clientMessage);
	}
	
	public Vector<Socket> getClients(){
		return clients;
	}
	
	
}
