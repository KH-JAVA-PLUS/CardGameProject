package play.single;

public class SingleGameDisplay {
	public SingleGameDisplay() {
		System.out.println("싱글게임 실행");

	}

}
