package play.multi;

public class MultiGameDisplay {
	public MultiGameDisplay(String userNick) {
		System.out.println("게임화면 닉네임 : "+userNick);
		System.out.println("멀티게임실행");
	}

}
