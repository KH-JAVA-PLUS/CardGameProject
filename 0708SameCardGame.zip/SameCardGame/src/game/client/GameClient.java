package game.client;

import login.view.LoginNickName;
import play.multi.MultiGameDisplay;

public class GameClient {
	public GameClient(String userNick) {
		int ip;
		int port;
		
		System.out.println("클라이언트 실행 후 : "+userNick);

		System.out.println("서버 접속 시도");

		new MultiGameDisplay(userNick);
	}

}
